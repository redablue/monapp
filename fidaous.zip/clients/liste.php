<?php
// C:\wamp64\www\fidaous\includes\header.php (VERSION MINIMALE POUR DEBUG)
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../includes/header.php';

// Seule la logique de redirection et l'exit sont là.
// AUCUN HTML ni autre echo/print avant.
if (!isset($_SESSION['user_id']) && basename($_SERVER['PHP_SELF']) != 'login.php') {
    header('Location: /fidaous/login.php');
    exit();
}
// Si tu vois cette phrase, c'est que la redirection n'a PAS EU LIEU.
// Cela signifie que le problème se produit ailleurs (soit l'utilisateur est déjà connecté,
// soit la page est login.php, soit le warning vient d'une autre page).
echo "DEBUG: Redirection non déclenchée ou exécutée. Utilisateur connecté ou sur login.php.";
// Tu peux même mettre un exit() ici pour ne pas continuer plus loin.
// exit();
?>