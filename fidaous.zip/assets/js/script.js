// js/script.js

// Tu pourras ajouter ton JavaScript personnalisé ici plus tard.
// Par exemple, pour des validations de formulaire avancées, des animations, etc.

document.addEventListener('DOMContentLoaded', function() {
    // Exemple : un message simple dans la console lorsque la page est chargée
    console.log('Application chargée !');
});