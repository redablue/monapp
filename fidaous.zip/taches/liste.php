<?php
// taches/liste.php
require_once __DIR__ . '/../includes/header.php';

// Vérifier l'autorisation :
// Administrateurs et gestionnaires : accès complet.
// Collaborateurs : voient leurs tâches et celles des dossiers où ils sont responsables.
if (!hasRequiredRole('collaborateur')) {
    redirect('/ton_projet_gestion/dashboard.php');
}

$search = $_GET['search'] ?? '';
$dossier_filter = $_GET['dossier_id'] ?? '';
$employe_filter = $_GET['employe_id'] ?? '';
$statut_filter = $_GET['statut'] ?? 'all';
$priorite_filter = $_GET['priorite'] ?? 'all';
$echeance_filter = $_GET['echeance'] ?? 'all'; // 'all', 'proche', 'retard'

// Récupérer la liste des dossiers pour le filtre
$dossiers_list = [];
try {
    $stmtDossiers = $pdo->query("SELECT id, titre FROM dossiers ORDER BY titre ASC");
    $dossiers_list = $stmtDossiers->fetchAll();
} catch (PDOException $e) {
    // Gérer l'erreur si nécessaire
}

// Récupérer la liste des employés pour le filtre
$employes_list = [];
try {
    $stmtEmployes = $pdo->query("SELECT id, prenom, nom FROM employes WHERE actif = TRUE ORDER BY prenom ASC");
    $employes_list = $stmtEmployes->fetchAll();
} catch (PDOException $e) {
    // Gérer l'erreur si nécessaire
}

$sql = "SELECT t.*, d.titre AS dossier_titre, c.nom_entreprise, e.prenom AS employe_prenom, e.nom AS employe_nom
        FROM taches t
        JOIN dossiers d ON t.dossier_id = d.id
        LEFT JOIN clients c ON d.client_id = c.id
        LEFT JOIN employes e ON t.employe_id = e.id
        WHERE (t.titre LIKE :search OR t.description LIKE :search OR d.titre LIKE :search OR c.nom_entreprise LIKE :search)";

// Appliquer les filtres
if (!empty($dossier_filter)) {
    $sql .= " AND t.dossier_id = :dossier_filter";
}
if (!empty($employe_filter)) {
    $sql .= " AND t.employe_id = :employe_filter";
}
if ($statut_filter != 'all') {
    $sql .= " AND t.statut = :statut_filter";
}
if ($priorite_filter != 'all') {
    $sql .= " AND t.priorite = :priorite_filter";
}

// Filtre sur les échéances
if ($echeance_filter == 'proche') {
    $sql .= " AND t.date_echeance BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND t.statut IN ('a_faire', 'en_cours')";
} elseif ($echeance_filter == 'retard') {
    $sql .= " AND t.date_echeance < CURDATE() AND t.statut IN ('a_faire', 'en_cours')";
}

// Logique de permission pour les collaborateurs
if ($_SESSION['user_role'] == 'collaborateur') {
    $sql .= " AND (t.employe_id = :current_user_id OR d.employe_responsable_id = :current_user_id)";
    // Un collaborateur ne voit que ses tâches ou les tâches des dossiers dont il est le responsable principal.
}

$sql .= " ORDER BY t.date_echeance ASC, t.priorite DESC";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':search', '%' . $search . '%');
if (!empty($dossier_filter)) {
    $stmt->bindParam(':dossier_filter', $dossier_filter, PDO::PARAM_INT);
}
if (!empty($employe_filter)) {
    $stmt->bindParam(':employe_filter', $employe_filter, PDO::PARAM_INT);
}
if ($statut_filter != 'all') {
    $stmt->bindParam(':statut_filter', $statut_filter);
}
if ($priorite_filter != 'all') {
    $stmt->bindParam(':priorite_filter', $priorite_filter);
}
if ($_SESSION['user_role'] == 'collaborateur') {
    $stmt->bindParam(':current_user_id', $_SESSION['user_id'], PDO::PARAM_INT);
}
$stmt->execute();
$taches = $stmt->fetchAll();

// Gestion de la suppression de tâche
if (isset($_GET['action']) && $_GET['action'] == 'supprimer' && isset($_GET['id'])) {
    if (hasRequiredRole('gestionnaire')) { // Seuls gestionnaires et administrateurs peuvent supprimer
        $tache_id = (int)$_GET['id'];
        try {
            $stmtDelete = $pdo->prepare("DELETE FROM taches WHERE id = :id");
            $stmtDelete->bindParam(':id', $tache_id, PDO::PARAM_INT);
            $stmtDelete->execute();

            if ($stmtDelete->rowCount()) {
                logActivity($pdo, 'Suppression tâche', 'taches', $tache_id, 'Tâche ' . $tache_id . ' supprimée.');
                $_SESSION['message'] = '<div class="alert alert-success" role="alert">Tâche supprimée avec succès.</div>';
            } else {
                $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Erreur lors de la suppression de la tâche ou tâche introuvable.</div>';
            }
        } catch (PDOException $e) {
            $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Erreur BD lors de la suppression de la tâche : ' . $e->getMessage() . '</div>';
        }
    } else {
        $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Vous n\'avez pas la permission de supprimer des tâches.</div>';
    }
    redirect('/ton_projet_gestion/taches/liste.php');
}
?>

<h1 class="mb-4">Gestion des Tâches</h1>

<?php
if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}
?>

<div class="card p-3 mb-4">
    <h5 class="card-title mb-3"><i class="fas fa-filter me-2"></i>Filtres et Recherche</h5>
    <form action="liste.php" method="GET" class="row g-3">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Rechercher par titre ou description..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-md-3">
            <select name="dossier_id" class="form-select">
                <option value="">Tous les dossiers</option>
                <?php foreach ($dossiers_list as $dossier): ?>
                    <option value="<?php echo $dossier['id']; ?>" <?php echo ($dossier_filter == $dossier['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($dossier['titre']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <select name="employe_id" class="form-select">
                <option value="">Tous les employés</option>
                <?php foreach ($employes_list as $employe): ?>
                    <option value="<?php echo $employe['id']; ?>" <?php echo ($employe_filter == $employe['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($employe['prenom'] . ' ' . $employe['nom']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <select name="statut" class="form-select">
                <option value="all" <?php echo ($statut_filter == 'all') ? 'selected' : ''; ?>>Tous les statuts</option>
                <option value="a_faire" <?php echo ($statut_filter == 'a_faire') ? 'selected' : ''; ?>>À faire</option>
                <option value="en_cours" <?php echo ($statut_filter == 'en_cours') ? 'selected' : ''; ?>>En cours</option>
                <option value="terminee" <?php echo ($statut_filter == 'terminee') ? 'selected' : ''; ?>>Terminée</option>
                <option value="en_retard" <?php echo ($statut_filter == 'en_retard') ? 'selected' : ''; ?>>En retard</option>
            </select>
        </div>
        <div class="col-md-2">
            <select name="priorite" class="form-select">
                <option value="all" <?php echo ($priorite_filter == 'all') ? 'selected' : ''; ?>>Toutes les priorités</option>
                <option value="basse" <?php echo ($priorite_filter == 'basse') ? 'selected' : ''; ?>>Basse</option>
                <option value="moyenne" <?php echo ($priorite_filter == 'moyenne') ? 'selected' : ''; ?>>Moyenne</option>
                <option value="haute" <?php echo ($priorite_filter == 'haute') ? 'selected' : ''; ?>>Haute</option>
                <option value="urgente" <?php echo ($priorite_filter == 'urgente') ? 'selected' : ''; ?>>Urgente</option>
            </select>
        </div>
        <div class="col-md-2">
            <select name="echeance" class="form-select">
                <option value="all" <?php echo ($echeance_filter == 'all') ? 'selected' : ''; ?>>Toutes les échéances</option>
                <option value="proche" <?php echo ($echeance_filter == 'proche') ? 'selected' : ''; ?>>Échéance proche (7 jours)</option>
                <option value="retard" <?php echo ($echeance_filter == 'retard') ? 'selected' : ''; ?>>En retard</option>
            </select>
        </div>
        <div class="col-md-auto">
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-1"></i>Appliquer Filtres</button>
        </div>
        <div class="col-md-auto">
            <?php if (hasRequiredRole('gestionnaire')): ?>
                <a href="ajouter.php" class="btn btn-success"><i class="fas fa-plus-circle me-1"></i>Ajouter une Tâche</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-hover table-striped">
        <thead class="table-dark">
            <tr>
                <th>Titre</th>
                <th>Dossier</th>
                <th>Client</th>
                <th>Assigné à</th>
                <th>Échéance</th>
                <th>Statut</th>
                <th>Priorité</th>
                <th>Est. (H)</th>
                <th>Réel (H)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($taches)): ?>
                <tr>
                    <td colspan="10" class="text-center">Aucune tâche trouvée.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($taches as $tache):
                    $row_class = '';
                    if ($tache['statut'] != 'terminee' && strtotime($tache['date_echeance']) < strtotime('today')) {
                        $row_class = 'table-danger'; // En retard
                    } elseif ($tache['statut'] != 'terminee' && strtotime($tache['date_echeance']) <= strtotime('+7 days')) {
                        $row_class = 'table-warning'; // Échéance proche
                    }
                ?>
                    <tr class="<?php echo $row_class; ?>">
                        <td><?php echo htmlspecialchars($tache['titre']); ?></td>
                        <td><?php echo htmlspecialchars($tache['dossier_titre']); ?></td>
                        <td><?php echo htmlspecialchars($tache['nom_entreprise']); ?></td>
                        <td><?php echo htmlspecialchars($tache['employe_prenom'] . ' ' . $tache['employe_nom']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($tache['date_echeance'])); ?></td>
                        <td>
                            <?php
                            $badge_class = '';
                            switch ($tache['statut']) {
                                case 'a_faire': $badge_class = 'bg-secondary'; break;
                                case 'en_cours': $badge_class = 'bg-primary'; break;
                                case 'terminee': $badge_class = 'bg-success'; break;
                                case 'en_retard': $badge_class = 'bg-danger'; break;
                                default: $badge_class = 'bg-info'; break;
                            }
                            ?>
                            <span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars(str_replace('_', ' ', ucfirst($tache['statut']))); ?></span>
                        </td>
                        <td>
                            <?php
                            $priorite_badge_class = '';
                            switch ($tache['priorite']) {
                                case 'basse': $priorite_badge_class = 'bg-info'; break;
                                case 'moyenne': $priorite_badge_class = 'bg-primary'; break;
                                case 'haute': $priorite_badge_class = 'bg-warning text-dark'; break;
                                case 'urgente': $priorite_badge_class = 'bg-danger'; break;
                                default: $priorite_badge_class = 'bg-secondary'; break;
                            }
                            ?>
                            <span class="badge <?php echo $priorite_badge_class; ?>"><?php echo htmlspecialchars(ucfirst($tache['priorite'])); ?></span>
                        </td>
                        <td><?php echo htmlspecialchars($tache['temps_estime_heures'] ?? '0.00'); ?></td>
                        <td><?php echo htmlspecialchars($tache['temps_reel_heures'] ?? '0.00'); ?></td>
                        <td>
                            <a href="modifier.php?id=<?php echo $tache['id']; ?>" class="btn btn-sm btn-info me-1" title="Modifier"><i class="fas fa-edit"></i></a>
                            <?php if (hasRequiredRole('gestionnaire')): // Seuls les gestionnaires et admins peuvent supprimer ?>
                                <a href="liste.php?action=supprimer&id=<?php echo $tache['id']; ?>" class="btn btn-sm btn-danger" title="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette tâche ?');"><i class="fas fa-trash-alt"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>