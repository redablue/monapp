<?php
// taches/modifier.php
require_once __DIR__ . '/../includes/header.php';

// Vérifier l'autorisation :
// Administrateurs et gestionnaires : accès complet.
// Collaborateurs : peuvent modifier si la tâche leur est assignée.
if (!hasRequiredRole('collaborateur')) {
    redirect('/ton_projet_gestion/dashboard.php');
}

$tache = null;
$message = '';
$tache_id = null;
$dossiers = [];
$employes = [];

if (isset($_GET['id'])) {
    $tache_id = (int)$_GET['id'];

    try {
        // Récupérer les informations de la tâche existante
        $stmtTache = $pdo->prepare("SELECT * FROM taches WHERE id = :id");
        $stmtTache->bindParam(':id', $tache_id, PDO::PARAM_INT);
        $stmtTache->execute();
        $tache = $stmtTache->fetch();

        if (!$tache) {
            $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Tâche introuvable.</div>';
            redirect('/ton_projet_gestion/taches/liste.php');
        }

        // Vérification de permission spécifique pour les collaborateurs
        if ($_SESSION['user_role'] == 'collaborateur' && $tache['employe_id'] != $_SESSION['user_id']) {
            // Si le collaborateur n'est pas assigné à cette tâche, vérifier s'il est responsable du dossier
            $stmtDossierResp = $pdo->prepare("SELECT employe_responsable_id FROM dossiers WHERE id = :dossier_id");
            $stmtDossierResp->bindParam(':dossier_id', $tache['dossier_id'], PDO::PARAM_INT);
            $stmtDossierResp->execute();
            $dossier_responsable_id = $stmtDossierResp->fetchColumn();

            if ($dossier_responsable_id != $_SESSION['user_id']) {
                $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Vous n\'avez pas la permission de modifier cette tâche.</div>';
                redirect('/ton_projet_gestion/taches/liste.php');
            }
        }

        // Récupérer les listes pour les sélecteurs
        $stmtDossiers = $pdo->query("SELECT id, titre FROM dossiers ORDER BY titre ASC");
        $dossiers = $stmtDossiers->fetchAll();

        $stmtEmployes = $pdo->query("SELECT id, prenom, nom FROM employes WHERE actif = TRUE ORDER BY prenom ASC");
        $employes = $stmtEmployes->fetchAll();

    } catch (PDOException $e) {
        $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Erreur lors du chargement des données de la tâche : ' . $e->getMessage() . '</div>';
        redirect('/ton_projet_gestion/taches/liste.php');
    }
} else {
    $_SESSION['message'] = '<div class="alert alert-danger" role="alert">ID tâche manquant.</div>';
    redirect('/ton_projet_gestion/taches/liste.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tache) {
    $dossier_id = $_POST['dossier_id'] ?? null;
    $employe_id = $_POST['employe_id'] ?? null;
    $titre = trim($_POST['titre'] ?? '');
    $description = trim($_POST['description'] ?? null);
    $date_debut = trim($_POST['date_debut'] ?? null);
    $date_echeance = trim($_POST['date_echeance'] ?? '');
    $statut = $_POST['statut'] ?? 'a_faire';
    $priorite = $_POST['priorite'] ?? 'moyenne';
    $temps_estime_heures = filter_var($_POST['temps_estime_heures'] ?? null, FILTER_VALIDATE_FLOAT);
    $temps_reel_heures = filter_var($_POST['temps_reel_heures'] ?? null, FILTER_VALIDATE_FLOAT);

    // Validation des champs
    if (empty($dossier_id) || empty($employe_id) || empty($titre) || empty($date_echeance)) {
        $message = '<div class="alert alert-danger" role="alert">Veuillez remplir tous les champs obligatoires.</div>';
    } elseif (strtotime($date_echeance) < strtotime($date_debut)) {
        $message = '<div class="alert alert-danger" role="alert">La date d\'échéance ne peut pas être antérieure à la date de début.</div>';
    } else {
        try {
            $sql = "UPDATE taches SET
                        dossier_id = :dossier_id,
                        employe_id = :employe_id,
                        titre = :titre,
                        description = :description,
                        date_debut = :date_debut,
                        date_echeance = :date_echeance,
                        statut = :statut,
                        priorite = :priorite,
                        temps_estime_heures = :temps_estime_heures,
                        temps_reel_heures = :temps_reel_heures
                    WHERE id = :id";
            $stmt = $pdo->prepare($sql);

            $stmt->bindParam(':dossier_id', $dossier_id, PDO::PARAM_INT);
            $stmt->bindParam(':employe_id', $employe_id, PDO::PARAM_INT);
            $stmt->bindParam(':titre', $titre);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':date_debut', $date_debut);
            $stmt->bindParam(':date_echeance', $date_echeance);
            $stmt->bindParam(':statut', $statut);
            $stmt->bindParam(':priorite', $priorite);
            $stmt->bindParam(':temps_estime_heures', $temps_estime_heures);
            $stmt->bindParam(':temps_reel_heures', $temps_reel_heures);
            $stmt->bindParam(':id', $tache_id, PDO::PARAM_INT);

            $stmt->execute();

            if ($stmt->rowCount()) {
                logActivity($pdo, 'Modification tâche', 'taches', $tache_id, 'Tâche "' . $titre . '" (ID ' . $tache_id . ') mise à jour.');
                $_SESSION['message'] = '<div class="alert alert-success" role="alert">Tâche mise à jour avec succès !</div>';
            } else {
                $_SESSION['message'] = '<div class="alert alert-info" role="alert">Aucune modification n\'a été apportée à la tâche.</div>';
            }
            redirect('/ton_projet_gestion/taches/liste.php');

        } catch (PDOException $e) {
            $message = '<div class="alert alert-danger" role="alert">Erreur lors de la mise à jour de la tâche : ' . $e->getMessage() . '</div>';
        }
    }
}
?>

<h1 class="mb-4">Modifier la Tâche : <?php echo htmlspecialchars($tache['titre'] ?? 'N/A'); ?></h1>

<?php echo $message; ?>

<div class="card p-4">
    <form action="modifier.php?id=<?php echo $tache_id; ?>" method="POST">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="dossier_id" class="form-label">Dossier Associé <span class="text-danger">*</span> :</label>
                <select class="form-select" id="dossier_id" name="dossier_id" required>
                    <option value="">Sélectionner un dossier</option>
                    <?php foreach ($dossiers as $dossier_option): ?>
                        <option value="<?php echo $dossier_option['id']; ?>" <?php echo ($tache['dossier_id'] == $dossier_option['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dossier_option['titre']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="employe_id" class="form-label">Assigné à <span class="text-danger">*</span> :</label>
                <select class="form-select" id="employe_id" name="employe_id" required>
                    <option value="">Sélectionner un employé</option>
                    <?php foreach ($employes as $employe_option): ?>
                        <option value="<?php echo $employe_option['id']; ?>" <?php echo ($tache['employe_id'] == $employe_option['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($employe_option['prenom'] . ' ' . $employe_option['nom']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label for="titre" class="form-label">Titre de la Tâche <span class="text-danger">*</span> :</label>
            <input type="text" class="form-control" id="titre" name="titre" required value="<?php echo htmlspecialchars($tache['titre'] ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Description :</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($tache['description'] ?? ''); ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="date_debut" class="form-label">Date et Heure de Début :</label>
                <input type="datetime-local" class="form-control" id="date_debut" name="date_debut" value="<?php echo htmlspecialchars(date('Y-m-d\TH:i', strtotime($tache['date_debut'] ?? 'now'))); ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label for="date_echeance" class="form-label">Date et Heure d'échéance <span class="text-danger">*</span> :</label>
                <input type="datetime-local" class="form-control" id="date_echeance" name="date_echeance" required value="<?php echo htmlspecialchars(date('Y-m-d\TH:i', strtotime($tache['date_echeance'] ?? '+1 week'))); ?>">
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label for="statut" class="form-label">Statut <span class="text-danger">*</span> :</label>
                <select class="form-select" id="statut" name="statut" required>
                    <option value="a_faire" <?php echo ($tache['statut'] == 'a_faire') ? 'selected' : ''; ?>>À faire</option>
                    <option value="en_cours" <?php echo ($tache['statut'] == 'en_cours') ? 'selected' : ''; ?>>En cours</option>
                    <option value="terminee" <?php echo ($tache['statut'] == 'terminee') ? 'selected' : ''; ?>>Terminée</option>
                    <option value="en_retard" <?php echo ($tache['statut'] == 'en_retard') ? 'selected' : ''; ?>>En retard</option>
                </select>
            </div>
            <div class="col-md-4 mb-3">
                <label for="priorite" class="form-label">Priorité <span class="text-danger">*</span> :</label>
                <select class="form-select" id="priorite" name="priorite" required>
                    <option value="basse" <?php echo ($tache['priorite'] == 'basse') ? 'selected' : ''; ?>>Basse</option>
                    <option value="moyenne" <?php echo ($tache['priorite'] == 'moyenne') ? 'selected' : ''; ?>>Moyenne</option>
                    <option value="haute" <?php echo ($tache['priorite'] == 'haute') ? 'selected' : ''; ?>>Haute</option>
                    <option value="urgente" <?php echo ($tache['priorite'] == 'urgente') ? 'selected' : ''; ?>>Urgente</option>
                </select>
            </div>
            <div class="col-md-4 mb-3">
                <label for="temps_estime_heures" class="form-label">Temps Estimé (heures) :</label>
                <input type="number" step="0.01" class="form-control" id="temps_estime_heures" name="temps_estime_heures" value="<?php echo htmlspecialchars($tache['temps_estime_heures'] ?? ''); ?>">
            </div>
        </div>
        <div class="mb-3">
            <label for="temps_reel_heures" class="form-label">Temps Réel (heures) :</label>
            <input type="number" step="0.01" class="form-control" id="temps_reel_heures" name="temps_reel_heures" value="<?php echo htmlspecialchars($tache['temps_reel_heures'] ?? ''); ?>">
        </div>

        <div class="d-flex justify-content-between mt-4">
            <a href="liste.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Retour à la liste</a>
            <button type="submit" class="btn btn-primary"><i class="fas fa-sync-alt me-1"></i>Mettre à jour la Tâche</button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>