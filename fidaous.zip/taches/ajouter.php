<?php
// taches/ajouter.php
require_once __DIR__ . '/../includes/header.php';

// Vérifier l'autorisation : seuls les gestionnaires et administrateurs peuvent ajouter une tâche
if (!hasRequiredRole('gestionnaire')) {
    redirect('/ton_projet_gestion/dashboard.php');
}

$message = '';
$dossiers = [];
$employes = [];

try {
    // Récupérer la liste des dossiers actifs (qui ne sont pas terminés ou annulés)
    $stmtDossiers = $pdo->query("SELECT id, titre FROM dossiers WHERE statut NOT IN ('termine', 'annule') ORDER BY titre ASC");
    $dossiers = $stmtDossiers->fetchAll();

    // Récupérer la liste des employés actifs
    $stmtEmployes = $pdo->query("SELECT id, prenom, nom FROM employes WHERE actif = TRUE ORDER BY prenom ASC");
    $employes = $stmtEmployes->fetchAll();

} catch (PDOException $e) {
    $message = '<div class="alert alert-danger" role="alert">Erreur lors du chargement des listes : ' . $e->getMessage() . '</div>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dossier_id = $_POST['dossier_id'] ?? null;
    $employe_id = $_POST['employe_id'] ?? null;
    $titre = trim($_POST['titre'] ?? '');
    $description = trim($_POST['description'] ?? null);
    $date_debut = trim($_POST['date_debut'] ?? date('Y-m-d H:i:s')); // Date et heure actuelles par défaut
    $date_echeance = trim($_POST['date_echeance'] ?? '');
    $statut = $_POST['statut'] ?? 'a_faire';
    $priorite = $_POST['priorite'] ?? 'moyenne';
    $temps_estime_heures = filter_var($_POST['temps_estime_heures'] ?? null, FILTER_VALIDATE_FLOAT);
    $temps_reel_heures = filter_var($_POST['temps_reel_heures'] ?? null, FILTER_VALIDATE_FLOAT);

    // Validation des champs
    if (empty($dossier_id) || empty($employe_id) || empty($titre) || empty($date_echeance)) {
        $message = '<div class="alert alert-danger" role="alert">Veuillez remplir tous les champs obligatoires (Dossier, Assigné à, Titre, Date d\'échéance).</div>';
    } elseif (strtotime($date_echeance) < strtotime($date_debut)) {
        $message = '<div class="alert alert-danger" role="alert">La date d\'échéance ne peut pas être antérieure à la date de début.</div>';
    } else {
        try {
            $sql = "INSERT INTO taches (dossier_id, employe_id, titre, description, date_debut, date_echeance, statut, priorite, temps_estime_heures, temps_reel_heures)
                    VALUES (:dossier_id, :employe_id, :titre, :description, :date_debut, :date_echeance, :statut, :priorite, :temps_estime_heures, :temps_reel_heures)";
            $stmt = $pdo->prepare($sql);

            $stmt->bindParam(':dossier_id', $dossier_id, PDO::PARAM_INT);
            $stmt->bindParam(':employe_id', $employe_id, PDO::PARAM_INT);
            $stmt->bindParam(':titre', $titre);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':date_debut', $date_debut);
            $stmt->bindParam(':date_echeance', $date_echeance);
            $stmt->bindParam(':statut', $statut);
            $stmt->bindParam(':priorite', $priorite);
            $stmt->bindParam(':temps_estime_heures', $temps_estime_heures); // FLOAT peut être null si validation échoue
            $stmt->bindParam(':temps_reel_heures', $temps_reel_heures); // FLOAT peut être null si validation échoue

            $stmt->execute();
            $last_id = $pdo->lastInsertId();

            logActivity($pdo, 'Création tâche', 'taches', $last_id, 'Nouvelle tâche "' . $titre . '" créée pour le dossier ID ' . $dossier_id . '.');
            $_SESSION['message'] = '<div class="alert alert-success" role="alert">Tâche ajoutée avec succès !</div>';
            redirect('/ton_projet_gestion/taches/liste.php');

        } catch (PDOException $e) {
            $message = '<div class="alert alert-danger" role="alert">Erreur lors de l\'ajout de la tâche : ' . $e->getMessage() . '</div>';
        }
    }
}
?>

<h1 class="mb-4">Ajouter une Nouvelle Tâche</h1>

<?php echo $message; ?>

<div class="card p-4">
    <form action="ajouter.php" method="POST">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="dossier_id" class="form-label">Dossier Associé <span class="text-danger">*</span> :</label>
                <select class="form-select" id="dossier_id" name="dossier_id" required>
                    <option value="">Sélectionner un dossier</option>
                    <?php foreach ($dossiers as $dossier): ?>
                        <option value="<?php echo $dossier['id']; ?>" <?php echo (isset($_POST['dossier_id']) && $_POST['dossier_id'] == $dossier['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dossier['titre']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="employe_id" class="form-label">Assigné à <span class="text-danger">*</span> :</label>
                <select class="form-select" id="employe_id" name="employe_id" required>
                    <option value="">Sélectionner un employé</option>
                    <?php foreach ($employes as $employe): ?>
                        <option value="<?php echo $employe['id']; ?>" <?php echo (isset($_POST['employe_id']) && $_POST['employe_id'] == $employe['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($employe['prenom'] . ' ' . $employe['nom']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label for="titre" class="form-label">Titre de la Tâche <span class="text-danger">*</span> :</label>
            <input type="text" class="form-control" id="titre" name="titre" required value="<?php echo htmlspecialchars($_POST['titre'] ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Description :</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="date_debut" class="form-label">Date et Heure de Début :</label>
                <input type="datetime-local" class="form-control" id="date_debut" name="date_debut" value="<?php echo htmlspecialchars(date('Y-m-d\TH:i', strtotime($_POST['date_debut'] ?? 'now'))); ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label for="date_echeance" class="form-label">Date et Heure d'échéance <span class="text-danger">*</span> :</label>
                <input type="datetime-local" class="form-control" id="date_echeance" name="date_echeance" required value="<?php echo htmlspecialchars(date('Y-m-d\TH:i', strtotime($_POST['date_echeance'] ?? '+1 week'))); ?>">
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label for="statut" class="form-label">Statut <span class="text-danger">*</span> :</label>
                <select class="form-select" id="statut" name="statut" required>
                    <option value="a_faire" <?php echo (($_POST['statut'] ?? '') == 'a_faire') ? 'selected' : ''; ?>>À faire</option>
                    <option value="en_cours" <?php echo (($_POST['statut'] ?? '') == 'en_cours') ? 'selected' : ''; ?>>En cours</option>
                    <option value="terminee" <?php echo (($_POST['statut'] ?? '') == 'terminee') ? 'selected' : ''; ?>>Terminée</option>
                    <option value="en_retard" <?php echo (($_POST['statut'] ?? '') == 'en_retard') ? 'selected' : ''; ?>>En retard</option>
                </select>
            </div>
            <div class="col-md-4 mb-3">
                <label for="priorite" class="form-label">Priorité <span class="text-danger">*</span> :</label>
                <select class="form-select" id="priorite" name="priorite" required>
                    <option value="basse" <?php echo (($_POST['priorite'] ?? '') == 'basse') ? 'selected' : ''; ?>>Basse</option>
                    <option value="moyenne" <?php echo (($_POST['priorite'] ?? '') == 'moyenne') ? 'selected' : ''; ?>>Moyenne</option>
                    <option value="haute" <?php echo (($_POST['priorite'] ?? '') == 'haute') ? 'selected' : ''; ?>>Haute</option>
                    <option value="urgente" <?php echo (($_POST['priorite'] ?? '') == 'urgente') ? 'selected' : ''; ?>>Urgente</option>
                </select>
            </div>
            <div class="col-md-4 mb-3">
                <label for="temps_estime_heures" class="form-label">Temps Estimé (heures) :</label>
                <input type="number" step="0.01" class="form-control" id="temps_estime_heures" name="temps_estime_heures" value="<?php echo htmlspecialchars($_POST['temps_estime_heures'] ?? ''); ?>">
            </div>
        </div>
        <div class="d-flex justify-content-between mt-4">
            <a href="liste.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Retour à la liste</a>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i>Ajouter la Tâche</button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>