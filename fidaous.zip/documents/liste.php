<?php
// documents/liste.php
require_once __DIR__ . '/../includes/header.php';

// Vérifier l'autorisation :
// Administrateurs et gestionnaires : accès complet.
// Collaborateurs : peuvent voir les documents des dossiers qui leur sont assignés ou liés à leurs clients.
if (!hasRequiredRole('collaborateur')) {
    redirect('/ton_projet_gestion/dashboard.php');
}

$search = $_GET['search'] ?? '';
$dossier_filter = $_GET['dossier_id'] ?? '';
$client_filter = $_GET['client_id'] ?? '';

// Récupérer la liste des dossiers pour le filtre
$dossiers_list = [];
try {
    $stmtDossiers = $pdo->query("SELECT id, titre FROM dossiers ORDER BY titre ASC");
    $dossiers_list = $stmtDossiers->fetchAll();
} catch (PDOException $e) {
    // Gérer l'erreur si nécessaire
}

// Récupérer la liste des clients pour le filtre
$clients_list = [];
try {
    $stmtClients = $pdo->query("SELECT id, nom_entreprise FROM clients ORDER BY nom_entreprise ASC");
    $clients_list = $stmtClients->fetchAll();
} catch (PDOException $e) {
    // Gérer l'erreur si nécessaire
}


$sql = "SELECT doc.*, d.titre AS dossier_titre, c.nom_entreprise, e.prenom AS uploader_prenom, e.nom AS uploader_nom
        FROM documents doc
        JOIN dossiers d ON doc.dossier_id = d.id
        JOIN clients c ON d.client_id = c.id
        LEFT JOIN employes e ON doc.uploader_id = e.id
        WHERE (doc.nom_fichier LIKE :search OR d.titre LIKE :search OR c.nom_entreprise LIKE :search)";

// Appliquer les filtres
if (!empty($dossier_filter)) {
    $sql .= " AND doc.dossier_id = :dossier_filter";
}
if (!empty($client_filter)) {
    // Joindre à nouveau les clients si le filtre par client est appliqué et pas déjà dans la clause ON
    // Non nécessaire ici car déjà joint via dossiers -> client
    $sql .= " AND c.id = :client_filter";
}

// Logique de permission pour les collaborateurs
if ($_SESSION['user_role'] == 'collaborateur') {
    $sql .= " AND (d.employe_responsable_id = :current_user_id OR c.employe_id = :current_user_id)";
    // Un collaborateur voit les documents des dossiers dont il est responsable
    // ou les documents liés à ses clients.
}

$sql .= " ORDER BY doc.date_upload DESC";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':search', '%' . $search . '%');
if (!empty($dossier_filter)) {
    $stmt->bindParam(':dossier_filter', $dossier_filter, PDO::PARAM_INT);
}
if (!empty($client_filter)) {
    $stmt->bindParam(':client_filter', $client_filter, PDO::PARAM_INT);
}
if ($_SESSION['user_role'] == 'collaborateur') {
    $stmt->bindParam(':current_user_id', $_SESSION['user_id'], PDO::PARAM_INT);
}
$stmt->execute();
$documents = $stmt->fetchAll();

// Gestion de la suppression de document
if (isset($_GET['action']) && $_GET['action'] == 'supprimer' && isset($_GET['id'])) {
    if (hasRequiredRole('gestionnaire')) { // Seuls les gestionnaires et administrateurs peuvent supprimer
        $document_id = (int)$_GET['id'];
        try {
            // Récupérer le chemin du fichier pour le supprimer du serveur
            $stmtFilePath = $pdo->prepare("SELECT chemin_fichier FROM documents WHERE id = :id");
            $stmtFilePath->bindParam(':id', $document_id, PDO::PARAM_INT);
            $stmtFilePath->execute();
            $file_path = $stmtFilePath->fetchColumn();

            $pdo->beginTransaction();

            $stmtDelete = $pdo->prepare("DELETE FROM documents WHERE id = :id");
            $stmtDelete->bindParam(':id', $document_id, PDO::PARAM_INT);
            $stmtDelete->execute();

            if ($stmtDelete->rowCount()) {
                // Supprimer le fichier physique du serveur
                if ($file_path && file_exists($file_path)) {
                    unlink($file_path);
                }
                logActivity($pdo, 'Suppression document', 'documents', $document_id, 'Document ' . $document_id . ' supprimé.');
                $_SESSION['message'] = '<div class="alert alert-success" role="alert">Document supprimé avec succès.</div>';
            } else {
                $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Erreur lors de la suppression du document ou document introuvable.</div>';
            }
            $pdo->commit();
        } catch (PDOException $e) {
            $pdo->rollBack();
            $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Erreur BD lors de la suppression du document : ' . $e->getMessage() . '</div>';
        }
    } else {
        $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Vous n\'avez pas la permission de supprimer des documents.</div>';
    }
    redirect('/ton_projet_gestion/documents/liste.php');
}
?>

<h1 class="mb-4">Gestion des Documents</h1>

<?php
if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}
?>

<div class="card p-3 mb-4">
    <h5 class="card-title mb-3"><i class="fas fa-filter me-2"></i>Filtres et Recherche</h5>
    <form action="liste.php" method="GET" class="row g-3">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Rechercher par nom de fichier, dossier, client..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-md-3">
            <select name="dossier_id" class="form-select">
                <option value="">Tous les dossiers</option>
                <?php foreach ($dossiers_list as $dossier): ?>
                    <option value="<?php echo $dossier['id']; ?>" <?php echo ($dossier_filter == $dossier['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($dossier['titre']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <select name="client_id" class="form-select">
                <option value="">Tous les clients</option>
                <?php foreach ($clients_list as $client): ?>
                    <option value="<?php echo $client['id']; ?>" <?php echo ($client_filter == $client['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($client['nom_entreprise']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-auto">
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-1"></i>Appliquer Filtres</button>
        </div>
        <div class="col-md-auto">
            <a href="uploader.php" class="btn btn-success"><i class="fas fa-upload me-1"></i>Uploader un Document</a>
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-hover table-striped">
        <thead class="table-dark">
            <tr>
                <th>Nom du Fichier</th>
                <th>Dossier</th>
                <th>Client</th>
                <th>Type</th>
                <th>Taille (Ko)</th>
                <th>Date d'Upload</th>
                <th>Uploader</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($documents)): ?>
                <tr>
                    <td colspan="8" class="text-center">Aucun document trouvé.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($documents as $doc): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($doc['nom_fichier']); ?></td>
                        <td><?php echo htmlspecialchars($doc['dossier_titre']); ?></td>
                        <td><?php echo htmlspecialchars($doc['nom_entreprise']); ?></td>
                        <td><?php echo htmlspecialchars($doc['type_mime']); ?></td>
                        <td><?php echo number_format($doc['taille_ko'], 0, ',', ' '); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($doc['date_upload'])); ?></td>
                        <td><?php echo htmlspecialchars($doc['uploader_prenom'] . ' ' . $doc['uploader_nom'] ?? 'N/A'); ?></td>
                        <td>
                            <a href="telecharger.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-primary me-1" title="Télécharger"><i class="fas fa-download"></i></a>
                            <?php if (hasRequiredRole('gestionnaire')): ?>
                                <a href="liste.php?action=supprimer&id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-danger" title="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce document ?');"><i class="fas fa-trash-alt"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>